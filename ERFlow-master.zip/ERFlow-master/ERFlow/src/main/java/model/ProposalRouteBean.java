package model;

public class ProposalRouteBean {
	
}
