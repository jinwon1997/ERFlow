package driver;

import java.util.Enumeration;
import java.util.HashMap;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpSessionContext;

import controller.UserController;
import model.UserBean;

public class UserActivityDriver {
	public static void main(String[] args) {
		UserController controller = new UserController();
		
	}
}
