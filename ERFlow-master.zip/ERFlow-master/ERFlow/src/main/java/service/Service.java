package service;

import java.util.UUID;

public interface Service {
	static final UUID SERVICE_UUID = UUID.randomUUID();
}
