$(function() {
	$('.cancel-board').on('click', function() {
		window.close();
	});
})