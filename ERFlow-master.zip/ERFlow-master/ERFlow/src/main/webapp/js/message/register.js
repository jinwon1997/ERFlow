/* 쪽지쓰기 */
function updateSelect(selectValue) {
		document.regFrm.receiverId.value = selectValue;
}