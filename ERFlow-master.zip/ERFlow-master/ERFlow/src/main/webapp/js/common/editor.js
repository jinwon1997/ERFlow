CKEDITOR.replace("editor1",{
				width: "1200px",
				height: "400px",
			});