$(function() {
	$("#cancel").on("click", function() {
		window.close();
	});
});
